<?php 
    require_once('../Connection/connection.php');

    $where = '';
	$postData = array_filter($_REQUEST);
	$postData = array_map(function($value) { return "'".$value."'"; }, $postData);

	$where = http_build_query($postData, '', ' and ');
	$where = urldecode($where);
	if ((strpos($where, "product_price=")) !== FALSE) { 
		$whatIWant = substr($where, strpos($where, "product_price=") + 14); 
		$value_replace = str_replace($whatIWant, 'CAST('.$whatIWant.' AS DECIMAL)', $where);
		$where = str_replace('product_price', 'CAST(pm.product_price AS DECIMAL)', $value_replace);
	}
?>
<br>
<table border="1" id="myTable" align="center">
	<tr bgcolor="#CCC">
		<th>Sale ID</th>
		<th>Customer Name</th>
		<th>Customer Mail</th>
		<th>Product ID</th>
		<th>Product Name</th>	
		<th>Product Price</th>
		<th>Sale Date</th>
	</tr>
	<?php 
		$sql = "select s.*,cm.id,cm.name as customer_name,cm.email as customer_mail,pm.product_name,pm.product_price from sales as s left join customer_master as cm on cm.id=s.customer_id left join product_master as pm on pm.id=s.product_id";
		if(!empty($where)) {
			$sql .=  ' where '.$where;
		}
		$results  = mysqli_query($conn, $sql);
		$rowcount = mysqli_num_rows($results);
		if($rowcount > 0) {
			while($r = mysqli_fetch_assoc($results)) {
	?>
	<tr>
		<td align="center"><?php echo $r['sale_id']; ?></td>
		<td align="center"><?php echo $r['customer_name']; ?></td>
		<td align="center"><?php echo $r['customer_mail']; ?></td>
		<td align="center"><?php echo $r['product_id']; ?></td>
		<td align="center"><?php echo $r['product_name']; ?></td>
		<td align="center" id="price"><?php echo $r['product_price']; ?></td>
		<td align="center"><?php echo $r['sale_date']; ?></td>
	</tr>
	<?php }} else { ?>
	<tr>
		<th colspan="9">No Record!!</th>
	</tr>
	<?php } ?>
	<tr>
		<th colspan="4"><font color="blue">Total Prize:</font></th>
		<td colspan="5" align="center" id="totalprize" style="color: blue;"></td>
	</tr>
</table>