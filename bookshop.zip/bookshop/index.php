<!DOCTYPE html>
<html>
<head>
<?php
	require_once('Connection/connection.php');

	if(isset($_REQUEST['submit'])) {
		if(isset($_FILES) && $_FILES['import']) {
			$jsonFile = $_FILES['import']['name'];
		}

	    $jsondata 	= file_get_contents($jsonFile);

	    $array_data = json_decode($jsondata, true);

	    $result 	= ''; 

	    if(!empty($array_data)) {
	    	foreach ($array_data as $row) {
	    		$sql 		= mysqli_query($conn,'select * from customer_master where email="'.trim($row['customer_mail']).'"');
	    		$totalrows  = mysqli_num_rows($sql);
	    		
	    		if($totalrows > 0) {
	    			$rows  = mysqli_fetch_assoc($sql);
	    			$customer_id 	=	$rows['id'];
	    		} else {
	    			$insert = mysqli_query($conn,'insert into customer_master (name,email) values ("'.$row['customer_name'].'","'.$row['customer_mail'].'")');
	    			if($insert) {
	    				$customer_id = mysqli_insert_id($conn);
	    			}
	    		}

	    		$sql 		= mysqli_query($conn,'select * from product_master where id="'.trim($row['product_id']).'"');
	    		$totalrows  = mysqli_num_rows($sql);

	    		if($totalrows > 0) {
	    			$product_id 	=	$row['product_id'];
	    		} else {
	    			$insert = mysqli_query($conn,'insert into product_master (product_name,product_price) values ("'.$row['product_name'].'","'.$row['product_price'].'")');
	    			if($insert) {
	    				$product_id = mysqli_insert_id($conn);
	    			}
	    		}
	    		$sql 		= mysqli_query($conn,'select * from sales where sale_id="'.trim($row['sale_id']).'"');
	    		$totalrows  = mysqli_num_rows($sql);
	    		if($totalrows == 0) {
	    			$result = mysqli_query($conn,'insert into sales (customer_id,product_id,sale_date) values ("'.$customer_id.'","'.$product_id.'","'.$row['sale_date'].'")');
	    		}
	      	}
	    }
	    
	    if($result) {
	        echo "<font color='green'>Records added successfully.</font>";
	    } else{
	        echo "<font color='red'>ERROR: Could not able to execute</font>";
	    }
	}
?>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Index</title>
	<script src="js/jquery.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			display();
			$(document).on('change','.search',function(){
				display();
			});
			function display() {
				var data = $('#form').serialize();
				$.ajax({
					type:'POST',
					url:'Response/response.php',
					data:data,
					success:function(res){
						$('#record').html(res);
						calc_total();
					}
				});
			}
			function calc_total(){
			  var sum = 0;
			  $("#myTable #price").each(function(){
			    sum += parseFloat($(this).text());
			  });
			  $('#totalprize').text(sum.toFixed(2));
			}
		});
	</script>
</head>
<body>
<br><br>
<form action="import.php" method="post">
	<input type="submit" value="Import">
</form>
<br><br>
<form name="form" id="form" action="">	
<table align="center">
	<tr>
		<th>Customer:</th>
		<td>
			<select name="customer_id" id="customer_id" class="search">
			<option value="">Select Customer:</option>
			<?php 
			$customers = mysqli_query($conn, "select id,name from customer_master");
			while($r = mysqli_fetch_assoc($customers)){
			?>
			<option value="<?php echo $r['id']; ?>" <?php if(isset($_REQUEST['email'])){if($_REQUEST['id']==$r['id']){echo 'selected';}}?>><?php echo $r['name']; ?></option>
			<?php } ?>
			</select>
		</td>
		<th>Product :</th>
		<td>
			<select name="product_id" id="product_id" class="search">
			<option value="">Select Product:</option>
			<?php 
			$products = mysqli_query($conn, "select id,product_name,product_price from product_master");
			while($r = mysqli_fetch_assoc($products)){
			?>
			<option value="<?php echo $r['id']; ?>" <?php if(isset($_REQUEST['id'])){if($_REQUEST['id']==$r['id']){echo 'selected';}}?>><?php echo $r['product_name']; ?></option>
			<?php } ?>
			</select>
		</td>
		<th>Price:</th>
		<td>
			<select name="product_price" id="product_price" class="search">
			<option value="">Select Price:</option>
			<?php
			$products = mysqli_query($conn, "select product_price from product_master");
			while($r = mysqli_fetch_assoc($products)){
			?>
			<option value="<?php echo $r['product_price']; ?>"><?php echo $r['product_price']; ?></option>
			<?php } ?>
			</select>
		</td>
	</tr>
</table>
</form>
<br>
<div id="record">
</div>
</body>
</html>