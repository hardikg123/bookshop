<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Import</title>
	</head>
<body>
<br><br>
<form action="http://localhost/bookshop/" method="post">
	<input type="submit" value="List">
</form>
<br>
<form action="http://localhost/bookshop/" method="post" enctype="multipart/form-data">
	<table align="center">
		<tr>
			<th>Import File</th>
		</tr>
	</table>
	<br>
	<table align="center">
		<tr>
			<th>Json File:</th>
			<td>
				<input type="file" name="import" accept=".json" required value="">
			</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td>
				<input type="submit" name="submit" value="Submit">
			</td>
		</tr>
	</table>
</form>
</body>
</html>